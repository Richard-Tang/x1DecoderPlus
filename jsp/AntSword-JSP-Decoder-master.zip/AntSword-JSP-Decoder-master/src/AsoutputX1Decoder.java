package src;

public class AsoutputX1Decoder {
    String res;

    public AsoutputX1Decoder(String str) {
        res = x1Encoder(str);
    }

    private String x1Encoder(String p) {
        StringBuilder result = new StringBuilder();
        char[] chars = Base64Encode(p).toCharArray();
        for (int i = 0; i < chars.length; i++) {
            result.append(chars[i] ^ 99).append("|");
        }
        return Base64Encode(result.toString());
    }

    private String Base64Encode(String str) {
        String version = System.getProperty("java.version");
        try {
            String ret = "";
            if (version.compareTo("1.9") >= 0) {
                Class Base64 = Class.forName("java.util.Base64");
                Object Encoder = Base64.getMethod("getEncoder", new Class[0]).invoke(Base64, new Object[]{});
                ret = (String) Encoder.getClass().getMethod("encodeToString", byte[].class).invoke(Encoder, str.getBytes());
            } else {
                Class Base64 = Class.forName("sun.misc.BASE64Encoder");
                Object Encoder = Base64.getDeclaredConstructor().newInstance();
                ret = (String) Encoder.getClass().getMethod("encode", byte[].class).invoke(Encoder, str.getBytes());
            }
            return ret;
        } catch (Exception e) {
            return str;
        }
    }

    @Override
    public String toString() {
        return res;
    }
}