'use strict';

 module.exports = {
   asoutput: (ext={}) => {
     return `###X1Decoder###`;
   },
   decode_buff: (buff) => {
    return Buffer.from(buff.toString(), 'base64');
   }
 }