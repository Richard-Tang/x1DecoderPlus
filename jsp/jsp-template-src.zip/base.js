//
// 基础信息模板
// 获取：当前路径、磁盘列表
//

module.exports = () => ({
  info: '###Info###',
  // 检测数据库函数支持
  probedb: '###Probedb###',
})
  